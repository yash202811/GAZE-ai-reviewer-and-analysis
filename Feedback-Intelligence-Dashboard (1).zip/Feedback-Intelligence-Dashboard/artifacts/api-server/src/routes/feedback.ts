import { Router, type IRouter } from "express";
import { AnalyzeFeedbackBody, AnalyzeFeedbackResponse } from "@workspace/api-zod";

const router: IRouter = Router();
type Sentiment = "positive" | "negative" | "neutral";

const LEXICON: Record<string, number> = {
  great: 0.8,
  excellent: 0.9,
  good: 0.6,
  amazing: 0.9,
  love: 0.8,
  loved: 0.8,
  best: 0.8,
  fast: 0.5,
  friendly: 0.6,
  clean: 0.5,
  helpful: 0.6,
  wonderful: 0.8,
  happy: 0.6,
  nice: 0.5,
  awesome: 0.9,
  satisfied: 0.6,
  comfortable: 0.5,
  quick: 0.4,
  delicious: 0.8,
  tasty: 0.7,
  fresh: 0.5,
  easy: 0.4,
  smooth: 0.4,
  professional: 0.5,
  efficient: 0.6,
  recommend: 0.6,
  perfect: 0.9,
  impressed: 0.6,
  courteous: 0.5,
  spacious: 0.4,
  affordable: 0.4,
  outstanding: 0.9,
  knowledgeable: 0.6,
  supportive: 0.6,
  reliable: 0.5,
  bad: -0.6,
  terrible: -0.9,
  poor: -0.6,
  worst: -0.9,
  slow: -0.5,
  rude: -0.7,
  dirty: -0.6,
  disappointed: -0.7,
  disappointing: -0.7,
  broken: -0.6,
  awful: -0.9,
  horrible: -0.9,
  delay: -0.5,
  delayed: -0.5,
  expensive: -0.4,
  cold: -0.3,
  noisy: -0.3,
  crowded: -0.3,
  unhelpful: -0.6,
  uncomfortable: -0.5,
  issue: -0.4,
  issues: -0.4,
  problem: -0.5,
  problems: -0.5,
  worse: -0.6,
  unacceptable: -0.8,
  understaffed: -0.5,
  outdated: -0.4,
  lacking: -0.4,
  insufficient: -0.4,
  mediocre: -0.4,
  stale: -0.5,
  overpriced: -0.5,
  waiting: -0.3,
  wait: -0.2,
  overcrowded: -0.5,
  malfunctioning: -0.6,
  unresponsive: -0.6,
  laggy: -0.4,
};

const STOPWORDS = new Set(
  (
    "a an the and or but if then so of to in on at for with is are was were be been being " +
    "this that these those it its as by from very really quite just not no do does did have " +
    "has had i we you they he she my our your their about into out up down over under again " +
    "more most also there here can could would should will"
  ).split(" "),
);

function analyzeSentiment(text: string) {
  const words = text
    .toLowerCase()
    .replace(/[^a-z0-9'\s]/g, " ")
    .split(/\s+/)
    .filter(Boolean);
  let total = 0;
  let matched = 0;

  words.forEach((word, index) => {
    let weight = LEXICON[word];
    if (weight === undefined) return;
    const previous = words[index - 1];
    if (
      previous === "not" ||
      previous === "no" ||
      previous === "never" ||
      (previous && previous.endsWith("n't"))
    ) {
      weight = -weight * 0.8;
    }
    total += weight;
    matched += 1;
  });

  const rawScore = matched === 0 ? 0 : total / matched;
  const score = Math.round(Math.max(-1, Math.min(1, rawScore)) * 100) / 100;
  const sentiment: Sentiment =
    score >= 0.05 ? "positive" : score <= -0.05 ? "negative" : "neutral";
  return { sentiment, score };
}

function extractKeywords(entries: Array<{ text: string }>) {
  const counts = new Map<string, number>();
  entries.forEach(({ text }) => {
    text
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, " ")
      .split(/\s+/)
      .filter((word) => word.length > 3 && !STOPWORDS.has(word))
      .forEach((word) => counts.set(word, (counts.get(word) ?? 0) + 1));
  });

  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([word, count]) => ({ word, count }));
}

router.post("/feedback/analyze", (req, res) => {
  const parsed = AnalyzeFeedbackBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Send at least one feedback entry with a text field." });
    return;
  }

  const { entries, datasetLabel } = parsed.data;
  const results = entries.map((entry, index) => ({
    ...entry,
    id: entry.id ?? index + 1,
    ...analyzeSentiment(entry.text),
  }));
  const summary = results.reduce(
    (counts, result) => {
      counts[result.sentiment] += 1;
      return counts;
    },
    { positive: 0, negative: 0, neutral: 0 },
  );

  const datedResults = results.filter((result) => result.date);
  const byDate = new Map<string, { sum: number; count: number }>();
  datedResults.forEach((result) => {
    const current = byDate.get(result.date!) ?? { sum: 0, count: 0 };
    current.sum += result.score;
    current.count += 1;
    byDate.set(result.date!, current);
  });
  const trend = [...byDate.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([date, value]) => ({
      date,
      avgScore: Math.round((value.sum / value.count) * 100) / 100,
    }));

  const keywords = extractKeywords(entries);
  const leadSentiment =
    summary.positive >= summary.negative && summary.positive >= summary.neutral
      ? "positive"
      : summary.negative >= summary.positive && summary.negative >= summary.neutral
        ? "negative"
        : "neutral";
  const insights = [
    `Most feedback is ${leadSentiment} (${Math.round((summary[leadSentiment] / results.length) * 100)}% of ${results.length} entries).`,
    ...(keywords[0]
      ? [`The most frequently mentioned keyword is "${keywords[0].word}", appearing ${keywords[0].count} times.`]
      : []),
    ...(summary.positive > 0 && summary.negative > 0
      ? [`Positive feedback outweighs negative feedback ${summary.positive} to ${summary.negative}.`]
      : []),
  ];

  const response = AnalyzeFeedbackResponse.parse({
    datasetLabel: datasetLabel || "Uploaded feedback",
    results,
    summary,
    keywords,
    trend,
    insights,
  });
  res.json(response);
});

export default router;