import { type CSSProperties, useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  Activity,
  ArrowDownRight,
  ArrowUpRight,
  BarChart3,
  Check,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  Clipboard,
  CloudUpload,
  Download,
  FileText,
  Filter,
  LayoutDashboard,
  LoaderCircle,
  MessageSquareText,
  MoreHorizontal,
  PanelLeft,
  PieChart,
  Search,
  Sparkles,
  Upload,
  X,
} from 'lucide-react';
import type {
  FeedbackAnalysis,
  FeedbackEntry,
  FeedbackResult,
} from '@workspace/api-client-react';
import {
  getHealthCheckQueryKey,
  useAnalyzeFeedback,
  useHealthCheck,
} from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';
import '../src/index.css';

const queryClient = new QueryClient();

const sampleAnalysis: FeedbackAnalysis = {
  datasetLabel: 'Spring pulse · 284 responses',
  summary: { positive: 168, negative: 71, neutral: 45 },
  keywords: [
    { word: 'service', count: 48 },
    { word: 'wait', count: 31 },
    { word: 'staff', count: 29 },
    { word: 'price', count: 22 },
    { word: 'quality', count: 19 },
    { word: 'hours', count: 15 },
  ],
  trend: [
    { date: 'Mar 04', avgScore: 0.22 },
    { date: 'Mar 11', avgScore: 0.31 },
    { date: 'Mar 18', avgScore: 0.18 },
    { date: 'Mar 25', avgScore: 0.42 },
    { date: 'Apr 01', avgScore: 0.51 },
    { date: 'Apr 08', avgScore: 0.47 },
    { date: 'Apr 15', avgScore: 0.59 },
  ],
  insights: [
    'People value the staff more than any other part of the experience, but long waits are eroding that goodwill.',
    'Positive sentiment is strongest on weekday mornings; service complaints cluster after 5pm.',
    'Price concerns are specific rather than broad: respondents ask for clearer bundles, not lower prices.',
  ],
  results: [
    { id: 'fb-001', text: 'The new check-in process is fast and genuinely less stressful.', category: 'Experience', date: '2024-04-15', sentiment: 'positive', score: 0.91 },
    { id: 'fb-002', text: 'I waited nearly 25 minutes even though there were only two people ahead of me.', category: 'Service', date: '2024-04-15', sentiment: 'negative', score: -0.82 },
    { id: 'fb-003', text: 'Staff were patient, clear, and remembered what I needed from last time.', category: 'People', date: '2024-04-14', sentiment: 'positive', score: 0.88 },
    { id: 'fb-004', text: 'The hours work for me. Nothing else to add.', category: 'Access', date: '2024-04-14', sentiment: 'neutral', score: 0.04 },
    { id: 'fb-005', text: 'I could not tell which package was best value without asking someone.', category: 'Pricing', date: '2024-04-13', sentiment: 'negative', score: -0.46 },
    { id: 'fb-006', text: 'A calm, friendly experience from start to finish.', category: 'Experience', date: '2024-04-13', sentiment: 'positive', score: 0.79 },
    { id: 'fb-007', text: 'The evening queue feels like a different operation entirely.', category: 'Service', date: '2024-04-12', sentiment: 'negative', score: -0.68 },
    { id: 'fb-008', text: 'Good quality and a thoughtful team. I will be back.', category: 'People', date: '2024-04-11', sentiment: 'positive', score: 0.86 },
    { id: 'fb-009', text: 'It was fine. I got what I came for.', category: 'Experience', date: '2024-04-10', sentiment: 'neutral', score: 0.12 },
    { id: 'fb-010', text: 'The price felt fair once the options were explained.', category: 'Pricing', date: '2024-04-09', sentiment: 'positive', score: 0.54 },
  ],
};

type SentimentFilter = 'all' | 'positive' | 'negative' | 'neutral';

function parseFeedbackText(raw: string): FeedbackEntry[] {
  return raw
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map<FeedbackEntry | null>((line, index) => {
      const cells = line.split(',').map((cell) => cell.trim().replace(/^["']|["']$/g, ''));
      if (cells.length >= 2 && (cells[0].toLowerCase() === 'text' || cells[0].toLowerCase() === 'comment')) {
        return null;
      }
      if (cells.length >= 3) {
        return { id: cells[0] || `row-${index + 1}`, text: cells[1], category: cells[2] || undefined, date: cells[3] || undefined };
      }
      return { id: `row-${index + 1}`, text: cells.join(', '), category: undefined, date: undefined };
    })
    .filter((entry): entry is FeedbackEntry => Boolean(entry?.text));
}

function formatDate(date?: string | null) {
  if (!date) return 'Undated';
  const parsed = new Date(date);
  if (Number.isNaN(parsed.getTime())) return date;
  return new Intl.DateTimeFormat('en', { month: 'short', day: 'numeric' }).format(parsed);
}

function sentimentLabel(value: SentimentFilter) {
  return value === 'all' ? 'All signals' : value.charAt(0).toUpperCase() + value.slice(1);
}

function sentimentColor(sentiment: FeedbackResult['sentiment']) {
  if (sentiment === 'positive') return 'hsl(153 35% 40%)';
  if (sentiment === 'negative') return 'hsl(14 64% 58%)';
  return 'hsl(200 12% 50%)';
}

function scoreLabel(score: number) {
  return `${score > 0 ? '+' : ''}${score.toFixed(2)}`;
}

function TrendChart({ trend }: { trend: FeedbackAnalysis['trend'] }) {
  const width = 660;
  const height = 190;
  const padX = 18;
  const padY = 22;
  const min = Math.min(-0.2, ...trend.map((point) => point.avgScore));
  const max = Math.max(0.8, ...trend.map((point) => point.avgScore));
  const x = (index: number) => padX + (index / Math.max(1, trend.length - 1)) * (width - padX * 2);
  const y = (score: number) => height - padY - ((score - min) / (max - min)) * (height - padY * 2);
  const points = trend.map((point, index) => `${x(index)},${y(point.avgScore)}`).join(' ');
  const baseline = y(0);

  return (
    <div className="mt-4" data-testid="chart-sentiment-trend">
      <svg className="sparkline h-[190px] w-full overflow-visible" viewBox={`0 0 ${width} ${height}`} role="img" aria-label="Sentiment score over time">
        <line x1={padX} y1={baseline} x2={width - padX} y2={baseline} stroke="hsl(200 12% 44% / .22)" strokeDasharray="3 5" />
        <line x1={padX} y1={padY} x2={width - padX} y2={padY} stroke="hsl(200 12% 44% / .1)" />
        <line x1={padX} y1={height - padY} x2={width - padX} y2={height - padY} stroke="hsl(200 12% 44% / .1)" />
        <polyline points={`${padX},${height - padY} ${points} ${width - padX},${height - padY}`} fill="hsl(14 64% 62% / .1)" stroke="none" />
        <polyline points={points} fill="none" stroke="hsl(14 64% 58%)" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
        {trend.map((point, index) => (
          <g key={`${point.date}-${index}`}>
            <circle cx={x(index)} cy={y(point.avgScore)} r="5" fill="hsl(42 33% 97%)" stroke="hsl(14 64% 58%)" strokeWidth="3" />
            <text x={x(index)} y={height - 2} textAnchor="middle" fill="hsl(200 12% 44%)" fontSize="11" fontFamily="IBM Plex Mono, monospace">{point.date}</text>
          </g>
        ))}
        <text x={width - padX} y={baseline - 7} textAnchor="end" fill="hsl(200 12% 44%)" fontSize="10" fontFamily="IBM Plex Mono, monospace">neutral</text>
      </svg>
    </div>
  );
}

type SignalFieldProps = {
  analysis: FeedbackAnalysis;
  selectedSignal: string;
  onSelect: (signal: string) => void;
};

function SignalField({ analysis, selectedSignal, onSelect }: SignalFieldProps) {
  const [tilt, setTilt] = useState({ x: -7, y: 8 });
  const total = analysis.summary.positive + analysis.summary.negative + analysis.summary.neutral;
  const signalNodes = [
    {
      key: 'positive',
      label: 'Positive',
      value: `${Math.round((analysis.summary.positive / total) * 100)}%`,
      detail: `${analysis.summary.positive} voices`,
      className: 'signal-node-positive',
      position: 'signal-node-a',
    },
    {
      key: 'negative',
      label: 'Negative',
      value: `${Math.round((analysis.summary.negative / total) * 100)}%`,
      detail: `${analysis.summary.negative} voices`,
      className: 'signal-node-negative',
      position: 'signal-node-b',
    },
    {
      key: 'neutral',
      label: 'Neutral',
      value: `${Math.round((analysis.summary.neutral / total) * 100)}%`,
      detail: `${analysis.summary.neutral} voices`,
      className: 'signal-node-neutral',
      position: 'signal-node-c',
    },
  ];

  function handlePointerMove(event: React.PointerEvent<HTMLDivElement>) {
    const bounds = event.currentTarget.getBoundingClientRect();
    const x = (event.clientX - bounds.left) / bounds.width - 0.5;
    const y = (event.clientY - bounds.top) / bounds.height - 0.5;
    setTilt({ x: y * -16, y: x * 18 });
  }

  function resetTilt() {
    setTilt({ x: -7, y: 8 });
  }

  return (
    <section
      className="signal-field rise-in rise-delay-1"
      style={{ '--scene-rotate-x': `${tilt.x}deg`, '--scene-rotate-y': `${tilt.y}deg` } as CSSProperties}
      onPointerMove={handlePointerMove}
      onPointerLeave={resetTilt}
      aria-label="Interactive 3D feedback signal field"
    >
      <div className="signal-field-copy">
        <div className="font-data text-[10px] uppercase tracking-[.18em] text-[hsl(var(--primary))]">
          Spatial read
        </div>
        <h2 className="mt-2 font-editorial text-3xl leading-none tracking-[-.05em]">
          Move through the signal.
        </h2>
        <p className="mt-3 max-w-xs text-xs leading-5 text-[hsl(var(--muted-foreground))]">
          Hover to shift perspective. Click a signal to bring the matching evidence into focus.
        </p>
        <div className="mt-6 flex items-center gap-2 font-data text-[10px] uppercase tracking-[.12em] text-[hsl(var(--muted-foreground))]">
          <span className="signal-live-dot" />
          Live analysis field
        </div>
      </div>

      <div className="signal-stage">
        <div className="signal-scene" style={{ transform: `rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)` }}>
          <div className="signal-grid signal-grid-back" />
          <div className="signal-grid signal-grid-floor" />
          <div className="signal-ring signal-ring-outer" />
          <div className="signal-ring signal-ring-mid" />
          <div className="signal-ring signal-ring-inner" />
          <div className="signal-core">
            <span className="signal-core-kicker">signal</span>
            <strong>{total}</strong>
            <span className="signal-core-label">voices read</span>
          </div>

          {signalNodes.map((node) => (
            <button
              key={node.key}
              type="button"
              className={`signal-node ${node.className} ${node.position} ${selectedSignal === node.key ? 'signal-node-selected' : ''}`}
              onClick={() => onSelect(node.key)}
              aria-pressed={selectedSignal === node.key}
              aria-label={`Filter by ${node.label} feedback`}
            >
              <span className="signal-node-label">{node.label}</span>
              <strong>{node.value}</strong>
              <span>{node.detail}</span>
            </button>
          ))}

          {analysis.keywords.slice(0, 4).map((keyword, index) => (
            <button
              key={keyword.word}
              type="button"
              className={`signal-keyword signal-keyword-${index + 1} ${selectedSignal === keyword.word ? 'signal-keyword-selected' : ''}`}
              onClick={() => onSelect(keyword.word)}
              aria-pressed={selectedSignal === keyword.word}
            >
              <span>#</span>{keyword.word}
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}

function Sidebar({
  onNavigate,
  activeSection,
  datasetLabel,
  total,
}: {
  onNavigate: (section: string) => void;
  activeSection: string;
  datasetLabel?: string;
  total: number;
}) {
  const navItems = [
    { label: 'Overview', caption: 'Read the pulse', icon: LayoutDashboard, section: 'overview' },
    { label: 'Evidence', caption: 'Inspect comments', icon: MessageSquareText, section: 'evidence' },
    { label: 'Themes', caption: 'Find patterns', icon: PieChart, section: 'themes' },
    { label: 'Trends', caption: 'Track direction', icon: BarChart3, section: 'trends' },
  ];
  return (
    <aside className="workspace-rail hidden min-h-[100dvh] w-[246px] shrink-0 flex-col bg-[hsl(var(--sidebar))] px-5 py-6 text-[hsl(var(--sidebar-foreground))] md:flex">
      <div className="rail-brand px-2">
        <img className="gaze-logo" src="/gaze-logo.png" alt="Gaze" />
        <div>
          <div className="mt-2 font-data text-[9px] uppercase tracking-[0.2em] text-[hsl(var(--sidebar-foreground)/.52)]">feedback intelligence</div>
        </div>
      </div>
      <div className="mt-12 px-2 font-data text-[10px] uppercase tracking-[0.2em] text-[hsl(var(--sidebar-foreground)/.44)]">Workspace</div>
      <nav className="mt-3 space-y-1" aria-label="Workspace sections">
        {navItems.map(({ label, caption, icon: Icon, section }) => (
          <button
            key={section}
            type="button"
            onClick={() => onNavigate(section)}
            className={`nav-item flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm ${activeSection === section ? 'bg-[hsl(var(--sidebar-accent))] font-semibold text-[hsl(var(--sidebar-accent-foreground))]' : 'text-[hsl(var(--sidebar-foreground)/.65)] hover:bg-[hsl(var(--sidebar-accent)/.7)] hover:text-[hsl(var(--sidebar-foreground))]'}`}
            data-testid={`button-nav-${section}`}
          >
            <Icon size={16} strokeWidth={activeSection === section ? 2.3 : 1.8} />
            <span className="flex min-w-0 flex-col">
              <span>{label}</span>
              <span className="nav-caption">{caption}</span>
            </span>
            {activeSection === section && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-[hsl(var(--sidebar-primary))]" />}
          </button>
        ))}
      </nav>
      <div className="rail-collection mt-8 rounded-xl border border-[hsl(var(--sidebar-border))] p-3.5">
        <div className="flex items-center justify-between">
          <span className="font-data text-[10px] uppercase tracking-[.14em] text-[hsl(var(--sidebar-foreground)/.48)]">Collection</span>
          <span className="h-1.5 w-1.5 rounded-full bg-[hsl(var(--secondary))]" />
        </div>
        <div className="mt-2 truncate text-sm font-semibold text-[hsl(var(--sidebar-foreground)/.9)]">{datasetLabel || 'No collection loaded'}</div>
        <div className="mt-3 flex items-center gap-2 text-xs text-[hsl(var(--sidebar-foreground)/.52)]">
          <span className="font-data text-[11px] text-[hsl(var(--sidebar-primary))]">{total}</span>
          <span>voices in this read</span>
        </div>
      </div>
      <div className="mt-auto rounded-xl border border-[hsl(var(--sidebar-border))] bg-[hsl(var(--sidebar-accent)/.48)] p-3.5">
        <div className="flex items-center gap-2 font-data text-[10px] uppercase tracking-[.14em] text-[hsl(var(--sidebar-foreground)/.48)]">
          <span className="h-1.5 w-1.5 rounded-full bg-[hsl(var(--secondary))]" />
          Analysis engine
        </div>
        <div className="mt-2 flex items-center justify-between">
          <span className="text-xs text-[hsl(var(--sidebar-foreground)/.72)]">Ready for evidence</span>
          <span className="font-data text-[10px] text-[hsl(var(--sidebar-foreground)/.45)]">v0.8</span>
        </div>
      </div>
    </aside>
  );
}

function SummaryStat({ label, value, detail, accent, icon: Icon }: { label: string; value: string; detail: string; accent: string; icon: typeof Activity }) {
  return (
    <div className="relative overflow-hidden border-r border-[hsl(var(--card-border))] px-5 py-5 first:pl-0 last:border-r-0 sm:px-6">
      <div className={`absolute left-0 top-0 h-1 w-10 ${accent}`} />
      <div className="flex items-center gap-2 text-[hsl(var(--muted-foreground))]">
        <Icon size={14} />
        <span className="font-data text-[10px] uppercase tracking-[.14em]">{label}</span>
      </div>
      <div className="mt-2 flex items-end gap-2">
        <span className="font-editorial text-4xl leading-none tracking-[-.05em]">{value}</span>
        <span className="mb-0.5 text-xs text-[hsl(var(--muted-foreground))]">{detail}</span>
      </div>
    </div>
  );
}

function SkeletonOverview() {
  return (
    <div className="space-y-5" aria-label="Loading analysis">
      <div className="h-24 animate-pulse rounded-xl bg-[hsl(var(--muted))]" />
      <div className="grid gap-5 lg:grid-cols-[1.2fr_.8fr]">
        <div className="h-72 animate-pulse rounded-xl bg-[hsl(var(--muted))]" />
        <div className="h-72 animate-pulse rounded-xl bg-[hsl(var(--muted))]" />
      </div>
    </div>
  );
}

function Home() {
  const [analysis, setAnalysis] = useState<FeedbackAnalysis | null>(sampleAnalysis);
  const [datasetLabel, setDatasetLabel] = useState(sampleAnalysis.datasetLabel);
  const [rawInput, setRawInput] = useState('');
  const [isIntakeOpen, setIsIntakeOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('overview');
  const [activeView, setActiveView] = useState<'overview' | 'evidence'>('overview');
  const [search, setSearch] = useState('');
  const [sentiment, setSentiment] = useState<SentimentFilter>('all');
  const [category, setCategory] = useState('all');
  const [expandedId, setExpandedId] = useState<string | number | null>(null);
  const [selectedSignal, setSelectedSignal] = useState('');
  const [copied, setCopied] = useState(false);
  const [fileName, setFileName] = useState('');
  const analyzeFeedback = useAnalyzeFeedback();
  const healthCheck = useHealthCheck({ query: { queryKey: getHealthCheckQueryKey() } });

  const categories = useMemo(() => {
    if (!analysis) return [];
    return Array.from(new Set(analysis.results.map((result) => result.category).filter(Boolean))) as string[];
  }, [analysis]);

  const filteredResults = useMemo(() => {
    if (!analysis) return [];
    const query = search.trim().toLowerCase();
    return analysis.results.filter((result) => {
      const matchesSearch = !query || [result.text, result.category, result.date].filter(Boolean).some((value) => String(value).toLowerCase().includes(query));
      const matchesSentiment = sentiment === 'all' || result.sentiment === sentiment;
      const matchesCategory = category === 'all' || result.category === category;
      return matchesSearch && matchesSentiment && matchesCategory;
    });
  }, [analysis, category, search, sentiment]);

  const averageScore = useMemo(() => {
    if (!analysis?.results.length) return 0;
    return analysis.results.reduce((sum, result) => sum + result.score, 0) / analysis.results.length;
  }, [analysis]);

  const total = analysis ? analysis.summary.positive + analysis.summary.negative + analysis.summary.neutral : 0;
  const positivePct = total ? Math.round((analysis!.summary.positive / total) * 100) : 0;

  function goTo(section: string) {
    setActiveSection(section);
    const element = document.getElementById(`section-${section}`);
    if (element) element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    if (section === 'evidence') setActiveView('evidence');
    if (section === 'overview' || section === 'themes' || section === 'trends') setActiveView('overview');
  }

  function loadSample() {
    setAnalysis(sampleAnalysis);
    setDatasetLabel(sampleAnalysis.datasetLabel);
    setRawInput('');
    setIsIntakeOpen(false);
    setSearch('');
    setSentiment('all');
    setCategory('all');
    setSelectedSignal('');
  }

  function analyze() {
    const entries = parseFeedbackText(rawInput);
    if (!entries.length) return;
    analyzeFeedback.mutate(
      { data: { datasetLabel: datasetLabel.trim() || 'Untitled collection', entries } },
      {
        onSuccess: (result) => {
          setAnalysis(result);
          setIsIntakeOpen(false);
          setSearch('');
          setSentiment('all');
          setCategory('all');
          setSelectedSignal('');
        },
      },
    );
  }

  function handleSignalSelect(signal: string) {
    setSelectedSignal(signal);
    if (signal === 'positive' || signal === 'negative' || signal === 'neutral') {
      setSentiment(signal);
      setActiveView('evidence');
      setActiveSection('evidence');
      window.setTimeout(() => document.getElementById('section-evidence')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 0);
      return;
    }
    setSearch(signal);
    setActiveView('evidence');
    setActiveSection('evidence');
    window.setTimeout(() => document.getElementById('section-evidence')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 0);
  }

  function handleFile(file?: File) {
    if (!file) return;
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = () => setRawInput(String(reader.result ?? ''));
    reader.readAsText(file);
  }

  function exportSnapshot() {
    if (!analysis) return;
    const lines = [
      analysis.datasetLabel,
      `Positive ${analysis.summary.positive} · Negative ${analysis.summary.negative} · Neutral ${analysis.summary.neutral}`,
      '',
      'Key insights',
      ...analysis.insights.map((insight, index) => `${index + 1}. ${insight}`),
    ];
    const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'feedback-intelligence-brief.txt';
    link.click();
    URL.revokeObjectURL(url);
  }

  async function copyBrief() {
    if (!analysis) return;
    const brief = `${analysis.datasetLabel}\n\n${analysis.insights.join('\n')}`;
    try {
      await navigator.clipboard.writeText(brief);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  }

  return (
    <div className="grain workspace-shell flex min-h-[100dvh]">
      <Sidebar onNavigate={goTo} activeSection={activeSection} datasetLabel={analysis?.datasetLabel} total={total} />
      <main className="min-w-0 flex-1">
        <header className="workspace-header sticky top-0 z-20 flex h-[76px] items-center justify-between border-b border-[hsl(var(--border)/.7)] bg-[hsl(var(--background)/.88)] px-5 backdrop-blur-md sm:px-8 lg:px-12">
          <div className="flex items-center gap-3">
            <button type="button" className="rounded-md p-1.5 text-[hsl(var(--muted-foreground))] md:hidden" data-testid="button-open-sidebar" aria-label="Open workspace navigation">
              <PanelLeft size={18} />
            </button>
            <div className="header-context">
              <div className="header-overline font-data text-[9px] uppercase tracking-[.18em] text-[hsl(var(--muted-foreground))]">Workspace</div>
              <div className="flex items-center gap-2">
                <span className="font-semibold tracking-[-.02em] text-[hsl(var(--foreground))]">Feedback intelligence</span>
                <ChevronRight size={13} className="text-[hsl(var(--muted-foreground)/.55)]" />
                <span className="hidden text-xs text-[hsl(var(--muted-foreground))] sm:inline">Overview</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 sm:gap-4">
            <div className="header-dataset hidden items-center gap-3 lg:flex">
              <div className="text-right">
                <div className="font-data text-[9px] uppercase tracking-[.12em] text-[hsl(var(--muted-foreground))]">Active collection</div>
                <div className="mt-0.5 max-w-[190px] truncate text-xs font-semibold text-[hsl(var(--foreground))]">{analysis?.datasetLabel || 'No collection loaded'}</div>
              </div>
              <span className="header-divider" />
              <span className="font-data text-[10px] text-[hsl(var(--muted-foreground))]">{total} voices</span>
            </div>
            <div className="header-status hidden items-center gap-2 rounded-full border border-[hsl(var(--border))] px-3 py-1.5 font-data text-[10px] uppercase tracking-[.12em] text-[hsl(var(--muted-foreground))] sm:flex">
              <span className={`h-1.5 w-1.5 rounded-full ${healthCheck.isError ? 'bg-[hsl(var(--destructive))]' : 'bg-[hsl(var(--secondary))]'} ${healthCheck.isLoading ? 'pulse-soft' : ''}`} />
              {healthCheck.isLoading ? 'Checking' : healthCheck.isError ? 'Offline' : 'Online'}
            </div>
            <button type="button" onClick={copyBrief} disabled={!analysis} className="hidden items-center gap-2 rounded-lg border border-[hsl(var(--border))] px-3 py-2 text-xs font-semibold text-[hsl(var(--foreground))] transition hover:bg-[hsl(var(--muted))] disabled:opacity-40 sm:flex" data-testid="button-copy-brief">
              {copied ? <Check size={14} /> : <Clipboard size={14} />}
              {copied ? 'Copied' : 'Copy brief'}
            </button>
            <button type="button" onClick={exportSnapshot} disabled={!analysis} className="flex items-center gap-2 rounded-lg bg-[hsl(var(--foreground))] px-3.5 py-2 text-xs font-semibold text-[hsl(var(--background))] transition hover:opacity-85 disabled:opacity-40" data-testid="button-export-snapshot">
              <Download size={14} />
              <span className="hidden sm:inline">Export snapshot</span>
            </button>
          </div>
        </header>

        <div className="mx-auto max-w-[1440px] px-5 py-8 sm:px-8 lg:px-12 lg:py-11">
          <section id="section-overview" className="scroll-mt-24 rise-in">
            <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
              <div>
                <div className="mb-3 flex items-center gap-2 font-data text-[10px] uppercase tracking-[.2em] text-[hsl(var(--primary))]">
                  <span className="h-px w-6 bg-[hsl(var(--primary))]" />
                  Decision desk
                </div>
                <h1 className="max-w-2xl font-editorial text-[clamp(2.65rem,5vw,4.9rem)] leading-[.98] tracking-[-.065em] text-[hsl(var(--foreground))]">The signal inside the noise.</h1>
                <p className="mt-4 max-w-xl text-sm leading-6 text-[hsl(var(--muted-foreground))]">Read the room before you act. Feedback intelligence turns scattered comments into a clear read on what deserves attention next.</p>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <button type="button" onClick={() => setIsIntakeOpen((open) => !open)} className="group flex items-center gap-2 rounded-lg border border-[hsl(var(--foreground))] bg-[hsl(var(--foreground))] px-4 py-2.5 text-sm font-semibold text-[hsl(var(--background))] transition hover:-translate-y-0.5" data-testid="button-new-analysis">
                  <CloudUpload size={16} />
                  New analysis
                  <ChevronDown size={14} className={`transition-transform ${isIntakeOpen ? 'rotate-180' : ''}`} />
                </button>
              </div>
            </div>

            {isIntakeOpen && (
              <section className="rise-in mt-7 overflow-hidden rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] shadow-[0_18px_50px_hsl(200_30%_16%/.08)]" data-testid="panel-dataset-intake">
                <div className="flex flex-col gap-5 p-5 sm:p-6 lg:flex-row lg:items-start lg:gap-8">
                  <div className="max-w-sm shrink-0">
                    <div className="font-data text-[10px] uppercase tracking-[.18em] text-[hsl(var(--primary))]">Bring your evidence</div>
                    <h2 className="mt-2 font-editorial text-2xl tracking-[-.04em]">A blank page is useful too.</h2>
                    <p className="mt-2 text-xs leading-5 text-[hsl(var(--muted-foreground))]">Paste one comment per line, or add a CSV with text, category, and date columns. We will do the sorting.</p>
                    <button type="button" onClick={loadSample} className="mt-5 text-xs font-semibold text-[hsl(var(--primary))] underline decoration-[hsl(var(--primary)/.35)] underline-offset-4" data-testid="button-load-sample">Load the spring pulse sample</button>
                  </div>
                  <div className="min-w-0 flex-1">
                    <label className="mb-1.5 block font-data text-[10px] uppercase tracking-[.14em] text-[hsl(var(--muted-foreground))]" htmlFor="dataset-label">Collection label</label>
                    <input id="dataset-label" value={datasetLabel} onChange={(event) => setDatasetLabel(event.target.value)} placeholder="e.g. Q2 member comments" className="mb-3 w-full rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--background))] px-3 py-2.5 text-sm outline-none transition placeholder:text-[hsl(var(--muted-foreground)/.7)] focus:border-[hsl(var(--primary))] focus:ring-2 focus:ring-[hsl(var(--ring)/.2)]" data-testid="input-dataset-label" />
                    <div className="relative">
                      <textarea value={rawInput} onChange={(event) => setRawInput(event.target.value)} placeholder={'Paste feedback here…\nOne comment per line'} rows={6} className="w-full resize-y rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--background))] px-3 py-3 text-sm leading-6 outline-none transition placeholder:text-[hsl(var(--muted-foreground)/.7)] focus:border-[hsl(var(--primary))] focus:ring-2 focus:ring-[hsl(var(--ring)/.2)]" data-testid="textarea-feedback-input" />
                      <div className="absolute bottom-3 right-3 flex items-center gap-2">
                        <label className="flex cursor-pointer items-center gap-1.5 rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-2.5 py-1.5 text-[11px] font-semibold text-[hsl(var(--muted-foreground))] transition hover:text-[hsl(var(--foreground))]" data-testid="label-upload-csv">
                          <Upload size={13} />
                          {fileName || 'Upload CSV'}
                          <input type="file" accept=".csv,.txt" className="sr-only" onChange={(event) => handleFile(event.target.files?.[0])} data-testid="input-upload-csv" />
                        </label>
                        {rawInput && <button type="button" onClick={() => { setRawInput(''); setFileName(''); }} className="rounded-md p-1.5 text-[hsl(var(--muted-foreground))] hover:bg-[hsl(var(--muted))]" aria-label="Clear pasted feedback" data-testid="button-clear-input"><X size={14} /></button>}
                      </div>
                    </div>
                    {analyzeFeedback.isError && <div className="mt-2 rounded-md bg-[hsl(var(--destructive)/.1)] px-3 py-2 text-xs text-[hsl(var(--destructive))]" data-testid="status-analysis-error">The analysis engine could not read this collection. Check the input and try again.</div>}
                    <div className="mt-3 flex justify-end">
                      <button type="button" disabled={!parseFeedbackText(rawInput).length || analyzeFeedback.isPending} onClick={analyze} className="flex items-center gap-2 rounded-lg bg-[hsl(var(--primary))] px-4 py-2.5 text-xs font-bold text-[hsl(var(--primary-foreground))] transition hover:brightness-95 disabled:cursor-not-allowed disabled:opacity-45" data-testid="button-run-analysis">
                        {analyzeFeedback.isPending ? <LoaderCircle size={14} className="animate-spin" /> : <Sparkles size={14} />}
                        {analyzeFeedback.isPending ? 'Reading the room…' : 'Analyze feedback'}
                      </button>
                    </div>
                  </div>
                </div>
              </section>
            )}

            {analysis && (
              <SignalField
                analysis={analysis}
                selectedSignal={selectedSignal}
                onSelect={handleSignalSelect}
              />
            )}

            <div className="mt-9 overflow-hidden rounded-xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] rise-in rise-delay-1" data-testid="panel-summary">
              {!analysis ? <SkeletonOverview /> : (
                <>
                  <div className="flex flex-col justify-between gap-3 border-b border-[hsl(var(--card-border))] px-5 py-4 sm:flex-row sm:items-center sm:px-6">
                    <div className="flex items-center gap-2">
                      <FileText size={15} className="text-[hsl(var(--primary))]" />
                      <span className="text-sm font-semibold" data-testid="text-dataset-label">{analysis.datasetLabel}</span>
                      <span className="rounded-full bg-[hsl(var(--muted))] px-2 py-0.5 font-data text-[10px] text-[hsl(var(--muted-foreground))]">{total} entries</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="font-data text-[10px] uppercase tracking-[.14em] text-[hsl(var(--muted-foreground))]">Last read today</span>
                      <button type="button" onClick={() => setIsIntakeOpen(true)} className="text-xs font-semibold text-[hsl(var(--primary))]" data-testid="button-change-dataset">Change dataset</button>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3">
                    <SummaryStat label="Positive" value={`${positivePct}%`} detail={`${analysis.summary.positive} voices`} accent="bg-[hsl(var(--secondary-foreground))]" icon={ArrowUpRight} />
                    <SummaryStat label="Negative" value={`${total ? Math.round((analysis.summary.negative / total) * 100) : 0}%`} detail={`${analysis.summary.negative} voices`} accent="bg-[hsl(var(--primary))]" icon={ArrowDownRight} />
                    <SummaryStat label="Average signal" value={scoreLabel(averageScore)} detail="from −1 to +1" accent="bg-[hsl(var(--accent))]" icon={Activity} />
                  </div>
                </>
              )}
            </div>
          </section>

          {analysis && (
            <>
              <section className="mt-9 flex items-center justify-between border-b border-[hsl(var(--border))]" aria-label="Analysis views">
                <div className="flex gap-5">
                  <button type="button" onClick={() => setActiveView('overview')} className={`border-b-2 px-1 pb-3 text-xs font-semibold ${activeView === 'overview' ? 'border-[hsl(var(--primary))] text-[hsl(var(--foreground))]' : 'border-transparent text-[hsl(var(--muted-foreground))]'}`} data-testid="button-view-overview">Analysis overview</button>
                  <button type="button" onClick={() => { setActiveView('evidence'); goTo('evidence'); }} className={`border-b-2 px-1 pb-3 text-xs font-semibold ${activeView === 'evidence' ? 'border-[hsl(var(--primary))] text-[hsl(var(--foreground))]' : 'border-transparent text-[hsl(var(--muted-foreground))]'}`} data-testid="button-view-evidence">Evidence table <span className="ml-1 font-data text-[10px] text-[hsl(var(--muted-foreground))]">{filteredResults.length}</span></button>
                </div>
                <div className="hidden items-center gap-1 pb-3 font-data text-[10px] uppercase tracking-[.12em] text-[hsl(var(--muted-foreground))] sm:flex"><CircleHelp size={13} /> scores reflect language, not truth</div>
              </section>

              {activeView === 'overview' && (
                <div className="rise-in mt-5 grid gap-5 lg:grid-cols-[1.18fr_.82fr]">
                  <section id="section-trends" className="scroll-mt-24 rounded-xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-5 sm:p-6" data-testid="card-trend">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="font-data text-[10px] uppercase tracking-[.15em] text-[hsl(var(--muted-foreground))]">Sentiment over time</div>
                        <h2 className="mt-1 font-editorial text-2xl tracking-[-.04em]">The temperature is moving up.</h2>
                      </div>
                      <div className="rounded-md bg-[hsl(var(--secondary)/.35)] px-2 py-1 font-data text-[10px] text-[hsl(var(--secondary-foreground))]">+18 pts</div>
                    </div>
                    <TrendChart trend={analysis.trend} />
                  </section>

                  <section id="section-themes" className="scroll-mt-24 rounded-xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-5 sm:p-6" data-testid="card-themes">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="font-data text-[10px] uppercase tracking-[.15em] text-[hsl(var(--muted-foreground))]">Language map</div>
                        <h2 className="mt-1 font-editorial text-2xl tracking-[-.04em]">What people keep saying.</h2>
                      </div>
                      <PieChart size={18} className="text-[hsl(var(--primary))]" />
                    </div>
                    <div className="mt-6 space-y-4">
                      {analysis.keywords.slice(0, 5).map((keyword, index) => {
                        const largest = Math.max(...analysis.keywords.map((item) => item.count), 1);
                        return (
                          <div key={keyword.word} data-testid={`row-keyword-${keyword.word}`}>
                            <div className="mb-1.5 flex items-center justify-between text-xs">
                              <span className="font-semibold">{keyword.word}</span>
                              <span className="font-data text-[10px] text-[hsl(var(--muted-foreground))]">{keyword.count} mentions</span>
                            </div>
                            <div className="h-1.5 overflow-hidden rounded-full bg-[hsl(var(--muted))]">
                              <div className={`metric-bar h-full rounded-full ${index === 0 ? 'bg-[hsl(var(--primary))]' : index === 1 ? 'bg-[hsl(var(--secondary-foreground))]' : 'bg-[hsl(var(--accent))]'}`} style={{ width: `${(keyword.count / largest) * 100}%` }} />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </section>

                  <section className="rounded-xl border border-[hsl(var(--card-border))] bg-[hsl(var(--foreground))] p-5 text-[hsl(var(--background))] sm:p-6 lg:col-span-2" data-testid="card-insights">
                    <div className="flex flex-col gap-6 lg:flex-row lg:items-start">
                      <div className="flex shrink-0 items-center gap-3 lg:w-[28%]">
                        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[hsl(var(--accent))] text-[hsl(var(--foreground))]"><Sparkles size={18} /></div>
                        <div>
                          <div className="font-data text-[10px] uppercase tracking-[.15em] text-[hsl(var(--background)/.55)]">Analyst notes</div>
                          <h2 className="mt-1 font-editorial text-2xl tracking-[-.04em]">Three things to carry forward.</h2>
                        </div>
                      </div>
                      <div className="grid flex-1 gap-4 sm:grid-cols-3">
                        {analysis.insights.slice(0, 3).map((insight, index) => (
                          <div key={insight} className="border-t border-[hsl(var(--background)/.18)] pt-3" data-testid={`text-insight-${index}`}>
                            <span className="font-data text-[10px] text-[hsl(var(--accent))]">0{index + 1}</span>
                            <p className="mt-2 text-sm leading-5 text-[hsl(var(--background)/.78)]">{insight}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </section>
                </div>
              )}

              {activeView === 'evidence' && (
                <section id="section-evidence" className="scroll-mt-24 rise-in mt-5 overflow-hidden rounded-xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))]" data-testid="section-evidence">
                  <div className="flex flex-col gap-4 border-b border-[hsl(var(--card-border))] p-5 sm:p-6 lg:flex-row lg:items-end lg:justify-between">
                    <div>
                      <div className="font-data text-[10px] uppercase tracking-[.15em] text-[hsl(var(--muted-foreground))]">Searchable evidence</div>
                      <h2 className="mt-1 font-editorial text-3xl tracking-[-.045em]">Read the reasons, not just the score.</h2>
                    </div>
                    <div className="relative w-full lg:max-w-xs">
                      <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[hsl(var(--muted-foreground))]" />
                      <input type="search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search comments…" className="w-full rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--background))] py-2.5 pl-9 pr-3 text-xs outline-none focus:border-[hsl(var(--primary))]" data-testid="input-search-evidence" />
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center gap-2 border-b border-[hsl(var(--card-border))] px-5 py-3 sm:px-6">
                    <Filter size={14} className="mr-1 text-[hsl(var(--muted-foreground))]" />
                    {(['all', 'positive', 'negative', 'neutral'] as SentimentFilter[]).map((option) => (
                      <button type="button" key={option} onClick={() => setSentiment(option)} className={`rounded-full px-3 py-1.5 text-[11px] font-semibold transition ${sentiment === option ? 'bg-[hsl(var(--foreground))] text-[hsl(var(--background))]' : 'bg-[hsl(var(--muted))] text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))]'}`} data-testid={`button-filter-${option}`}>{sentimentLabel(option)}</button>
                    ))}
                    <select value={category} onChange={(event) => setCategory(event.target.value)} className="ml-auto rounded-md border border-[hsl(var(--input))] bg-[hsl(var(--background))] px-2.5 py-1.5 text-[11px] font-semibold outline-none" data-testid="select-category-filter">
                      <option value="all">All themes</option>
                      {categories.map((item) => <option key={item} value={item}>{item}</option>)}
                    </select>
                    {(search || sentiment !== 'all' || category !== 'all') && <button type="button" onClick={() => { setSearch(''); setSentiment('all'); setCategory('all'); }} className="flex items-center gap-1 text-[11px] font-semibold text-[hsl(var(--primary))]" data-testid="button-reset-filters"><X size={12} /> Reset</button>}
                  </div>
                  {filteredResults.length === 0 ? (
                    <div className="flex min-h-64 flex-col items-center justify-center px-6 text-center" data-testid="empty-evidence-state">
                      <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[hsl(var(--muted))]"><Search size={18} className="text-[hsl(var(--muted-foreground))]" /></div>
                      <h3 className="mt-3 font-editorial text-xl">No matching voices.</h3>
                      <p className="mt-1 max-w-xs text-xs leading-5 text-[hsl(var(--muted-foreground))]">Try a broader phrase, or clear the filters to return to the full read.</p>
                    </div>
                  ) : (
                    <div className="scrollbar-subtle overflow-x-auto">
                      <table className="w-full min-w-[700px] text-left">
                        <thead className="bg-[hsl(var(--muted)/.42)]">
                          <tr className="font-data text-[10px] uppercase tracking-[.13em] text-[hsl(var(--muted-foreground))]">
                            <th className="px-5 py-3 font-medium sm:px-6">Comment</th>
                            <th className="w-32 px-3 py-3 font-medium">Signal</th>
                            <th className="w-28 px-3 py-3 font-medium">Theme</th>
                            <th className="w-24 px-3 py-3 font-medium">Date</th>
                            <th className="w-9 px-3 py-3" />
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[hsl(var(--card-border))]">
                          {filteredResults.map((result, index) => {
                            const rowId = result.id ?? `result-${index}`;
                            const isExpanded = expandedId === rowId;
                            return (
                              <tr key={String(rowId)} className="evidence-row align-top" data-testid={`row-evidence-${rowId}`}>
                                <td className="px-5 py-4 sm:px-6">
                                  <button type="button" onClick={() => setExpandedId(isExpanded ? null : rowId)} className="max-w-[520px] text-left text-sm leading-5 text-[hsl(var(--foreground))]" data-testid={`button-expand-evidence-${rowId}`}>
                                    <span className={isExpanded ? '' : 'line-clamp-2'}>{result.text}</span>
                                  </button>
                                </td>
                                <td className="px-3 py-4">
                                  <div className="flex items-center gap-2">
                                    <span className="h-2 w-2 rounded-full" style={{ backgroundColor: sentimentColor(result.sentiment) }} />
                                    <span className="text-xs font-semibold capitalize">{result.sentiment}</span>
                                  </div>
                                  <div className="mt-1 font-data text-[10px] text-[hsl(var(--muted-foreground))]">{scoreLabel(result.score)}</div>
                                </td>
                                <td className="px-3 py-4 text-xs text-[hsl(var(--muted-foreground))]">{result.category || 'Uncategorized'}</td>
                                <td className="px-3 py-4 font-data text-[10px] text-[hsl(var(--muted-foreground))]">{formatDate(result.date)}</td>
                                <td className="px-3 py-4"><button type="button" onClick={() => setExpandedId(isExpanded ? null : rowId)} className="rounded p-1 text-[hsl(var(--muted-foreground))] hover:bg-[hsl(var(--muted))]" aria-label={isExpanded ? 'Collapse evidence' : 'Expand evidence'} data-testid={`button-toggle-evidence-${rowId}`}><MoreHorizontal size={15} /></button></td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                  <div className="border-t border-[hsl(var(--card-border))] px-5 py-3 font-data text-[10px] uppercase tracking-[.12em] text-[hsl(var(--muted-foreground))] sm:px-6">{filteredResults.length} of {total} voices shown</div>
                </section>
              )}
            </>
          )}
        </div>
      </main>
    </div>
  );
}

function Router() {
  return (
    <ErrorBoundary resetKey={useLocation()[0]}>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </ErrorBoundary>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;