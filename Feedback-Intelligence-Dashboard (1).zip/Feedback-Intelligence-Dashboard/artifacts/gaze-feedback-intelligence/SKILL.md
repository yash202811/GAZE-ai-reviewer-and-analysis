---
name: gaze-feedback-intelligence
description: Visual language and reusable component guidance extracted from the Gaze Feedback Intelligence dashboard.
---

# Gaze Feedback Intelligence

Gaze is a dark-first editorial design system for turning qualitative feedback
into a clear, spatial read. Its visual language combines deep wine surfaces,
burgundy action color, warm editorial display type, and compact data labels.

## Source and provenance

This system was extracted from the existing `artifacts/feedback-intelligence`
web app. The source defines the current product composition in
`src/App.tsx`, the visual tokens and interaction styling in `src/index.css`,
and the real Gaze wordmark in `public/gaze-logo.png`.

The source app is a dashboard rather than a standalone component library. Its
reusable primitive source is the local shadcn/Radix family under
`src/components/ui`; the current product composition also uses direct semantic
HTML and Lucide icons for the branded navigation, evidence views, and spatial
signal field.

## What's here

- `tokens.json` — the DTCG source of truth for light and dark color roles,
  typography, spacing, and radius.
- `docs/references/logos/gaze-logo.png` — the retained Gaze wordmark.
- `docs/references/component-inventory.md` — normalized component inventory
  and pilot plan extracted from the source app.
- `src/preview/` — the living foundations, brand, usage, motion, applied
  pattern, and component previews.

## Visual and composition rules

- Prefer the dark wine theme for product surfaces. The light mode is a
  derived, warm neutral counterpart for documentation and light contexts.
- Use burgundy `primary` for actions, active navigation, focus, and selected
  states. Use terracotta `secondary` and rose `accent` as supporting emphasis.
- Use Bodoni Moda for insight-led display headlines, DM Sans for interface and
  body copy, and IBM Plex Mono for compact metadata, labels, and status text.
- Keep hierarchy editorial: a short uppercase mono eyebrow, a concise serif
  headline, then a readable sans explanation.
- Keep cards and controls softly rounded with the base radius; separate layers
  with subtle borders and tonal surfaces rather than heavy shadows.
- When using spatial or animated surfaces, motion should reveal hierarchy or
  respond to a user action. Honor reduced-motion preferences.
- Keep evidence claims measured. Sentiment and scores describe language
  patterns, not objective truth.

## Composition rules

- Preserve a calm reading path from collection context to signal to evidence.
- Keep navigation functional and sparse; labels should name the user's next
  decision, not simulate system telemetry.
- Use the Gaze wordmark on dark surfaces with enough clear space and never
  place it over a busy visualization.
- Charts and signal nodes should use the chart palette consistently and retain
  readable labels at mobile widths.

## Component usage

Use the generated token theme and the component families in
`src/components/ui/`. Product-specific navigation, signal-field compositions,
and feedback evidence layouts remain in consuming applications; they should
consume these tokens rather than copy their values.