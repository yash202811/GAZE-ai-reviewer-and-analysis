# Gaze component inventory

## Source

- **Source artifact:** `artifacts/feedback-intelligence`
- **Primary composition:** `src/App.tsx`
- **Theme source:** `src/index.css`
- **Primitive source:** `src/components/ui/`
- **Brand asset:** `public/gaze-logo.png`

The source application is composed mostly from semantic HTML, Tailwind
utilities, Lucide icons, and a local shadcn/Radix primitive library. The
inventory below keeps the reusable families that are useful to future Gaze
consumers while leaving product-specific dashboard compositions in the app.

## Pilot chunk

| Family | Reference | Dependencies | Evidence | Status |
| --- | --- | --- | --- | --- |
| Button | `components/button.md` | class-variance-authority, Radix Slot | New analysis, copy brief, export snapshot actions | implemented |
| Card | `components/card.md` | class-variance-authority | Dashboard panels, evidence sections, collection context | implemented |
| Badge | `components/badge.md` | class-variance-authority | Dataset counts, status labels, sentiment metadata | implemented |
| Input | `components/input.md` | Radix-compatible focus styles | Collection label, search and intake controls | implemented |
| Switch | `components/switch.md` | Radix Switch | Shared primitive library; useful for future preferences | implemented |

## Later families

The scaffolded library retains the source app's reusable shadcn/Radix family
set for later documentation and consumer use:

- Forms and inputs: Label, Textarea, Select, Checkbox, Radio Group, Slider,
  Calendar, Field, Form, Input Group, Input OTP, Switch.
- Navigation and overlays: Sidebar, Breadcrumb, Tabs, Dropdown Menu, Dialog,
  Sheet, Drawer, Popover, Tooltip, Command, Menubar, Navigation Menu.
- Data and feedback: Table, Chart, Progress, Skeleton, Spinner, Toast,
  Sonner, Alert, Empty, Badge, Avatar, Item, Kbd.
- Structure and actions: Accordion, Collapsible, Carousel, Separator,
  Scroll Area, Resizable, Toggle, Toggle Group, Button Group, Aspect Ratio.

These families are retained as themed primitives; product-specific signal
fields, evidence tables, and insight compositions are not promoted into the
library as generic components.