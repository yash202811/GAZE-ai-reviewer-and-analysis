# Badge

**Source evidence:** Dataset counts, compact metadata, status, and sentiment
labels use small pill-like labels in the source composition.
The reusable primitive source is `src/components/ui/badge.tsx`.

**Gaze treatment:** Keep badges compact and mono when they carry data. Use
primary, secondary, outline, and destructive variants to distinguish state,
not to add decoration.