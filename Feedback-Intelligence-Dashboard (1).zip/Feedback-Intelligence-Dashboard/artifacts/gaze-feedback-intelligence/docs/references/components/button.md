# Button

**Source evidence:** `artifacts/feedback-intelligence/src/App.tsx` uses button
elements for navigation, analysis, copy, export, filters, and evidence actions.
The reusable primitive source is `src/components/ui/button.tsx`.

**Gaze treatment:** Burgundy primary actions use warm light text. Outline and
ghost actions use the same compact radius, subtle border, and restrained hover
surface. Destructive actions use the destructive token.

**Required states:** default, hover, focus-visible, active, disabled, and
icon-only where the surrounding label is available through accessible text.