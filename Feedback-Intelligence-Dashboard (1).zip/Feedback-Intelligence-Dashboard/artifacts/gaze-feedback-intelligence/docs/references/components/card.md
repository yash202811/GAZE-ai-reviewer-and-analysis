# Card

**Source evidence:** The dashboard uses bordered tonal panels for the signal
field, collection context, charts, analyst notes, and evidence views.
The reusable primitive source is `src/components/ui/card.tsx`.

**Gaze treatment:** Cards use the `card` surface, a quiet border, and the base
radius. Use a larger editorial headline inside a card only when it establishes
the section's reading purpose.