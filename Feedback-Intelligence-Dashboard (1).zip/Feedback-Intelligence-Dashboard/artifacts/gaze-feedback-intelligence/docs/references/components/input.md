# Input

**Source evidence:** The source app includes searchable evidence, collection
label editing, CSV/text intake, and category filtering controls.
The reusable primitive source is `src/components/ui/input.tsx`.

**Gaze treatment:** Inputs use the input border and card/background surface,
with the burgundy ring for focus. Labels are DM Sans for readable forms;
metadata and helper copy can use IBM Plex Mono.