# Switch

**Source evidence:** The primitive library includes Radix-backed binary
controls and the design system preview uses the switch as a representative
stateful control.
The reusable primitive source is `src/components/ui/switch.tsx`.

**Gaze treatment:** The on state uses the primary burgundy; the off state uses
muted surfaces and borders. Preserve keyboard focus and visible disabled
states.