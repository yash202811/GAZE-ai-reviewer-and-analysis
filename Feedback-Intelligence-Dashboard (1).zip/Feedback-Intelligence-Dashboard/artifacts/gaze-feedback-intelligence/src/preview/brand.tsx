import { Guidelines } from './parts';

const logoUrl = `${import.meta.env.BASE_URL}gaze-logo.png`;

export function BrandLogoPage() {
  return (
    <div className="space-y-6">
      <section className="rounded-xl border bg-card p-6 text-card-foreground">
        <div className="rounded-lg bg-sidebar p-8">
          <img
            src={logoUrl}
            alt="Gaze"
            className="h-auto w-48 brightness-0 invert"
          />
          <p className="mt-4 font-mono text-[10px] uppercase tracking-[.18em] text-sidebar-foreground/60">
            Feedback intelligence
          </p>
        </div>
        <div className="mt-5">
          <h2 className="font-serif text-2xl tracking-tight">Gaze wordmark</h2>
          <p className="mt-2 max-w-xl text-sm text-muted-foreground">
            The eye-led wordmark anchors the system in attention, observation,
            and a close read of what people are saying.
          </p>
        </div>
      </section>

      <section className="rounded-xl border bg-card p-6 text-card-foreground">
        <h2 className="font-semibold">Usage</h2>
        <div className="mt-4">
          <Guidelines
            items={[
              { kind: 'do', text: 'Use the full wordmark in the primary product rail or brand header.' },
              { kind: 'do', text: 'Use the light treatment on the dark Gaze surfaces used by the dashboard.' },
              { kind: 'dont', text: 'Do not redraw, stretch, crop, or place the mark over a busy visualization.' },
            ]}
          />
        </div>
      </section>
    </div>
  );
}