import { Guidelines } from './parts';

export function ContentPage() {
  return (
    <div className="space-y-6">
      <section className="rounded-xl border bg-card p-6 text-card-foreground">
        <p className="font-mono text-[10px] uppercase tracking-[.16em] text-primary">
          Voice and tone
        </p>
        <h2 className="mt-3 max-w-2xl font-serif text-4xl leading-none tracking-[-.04em]">
          Say what the evidence means.
        </h2>
        <p className="mt-4 max-w-xl text-muted-foreground">
          Gaze uses calm, direct language that helps people move from a
          collection of comments to a decision they can act on.
        </p>
      </section>
      <section className="rounded-xl border bg-card p-6 text-card-foreground">
        <Guidelines
          items={[
            { kind: 'do', text: 'Use plain language and name the implication, not just the metric.' },
            { kind: 'do', text: 'Use short editorial headings to create a clear reading order.' },
            { kind: 'dont', text: 'Do not overclaim: scores describe language patterns, not objective truth.' },
            { kind: 'dont', text: 'Do not fill quiet states with invented activity or decorative status language.' },
          ]}
        />
      </section>
    </div>
  );
}

export function MotionPage() {
  return (
    <div className="space-y-6">
      <section className="rounded-xl border bg-card p-6 text-card-foreground">
        <p className="font-mono text-[10px] uppercase tracking-[.16em] text-primary">
          Motion principles
        </p>
        <h2 className="mt-3 font-serif text-3xl tracking-tight">Motion follows attention.</h2>
        <div className="mt-6 grid gap-3 sm:grid-cols-3">
          {[
            ['Reveal', 'Use short rise-in transitions to establish hierarchy.'],
            ['Respond', 'Use small translations and rings to show interaction.'],
            ['Respect', 'Disable non-essential motion for reduced-motion users.'],
          ].map(([label, description]) => (
            <div key={label} className="rounded-lg border bg-muted/40 p-4">
              <p className="font-mono text-[10px] uppercase tracking-[.14em] text-primary">{label}</p>
              <p className="mt-2 text-sm text-muted-foreground">{description}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

export function AppliedDashboardPage() {
  return (
    <div className="space-y-6">
      <section className="overflow-hidden rounded-xl border bg-card text-card-foreground">
        <div className="grid gap-0 lg:grid-cols-[.8fr_1.2fr]">
          <div className="p-6">
            <p className="font-mono text-[10px] uppercase tracking-[.16em] text-primary">Applied pattern</p>
            <h2 className="mt-3 font-serif text-3xl leading-none tracking-[-.04em]">
              Spatial read
            </h2>
            <p className="mt-3 text-sm text-muted-foreground">
              A layered signal field turns sentiment, themes, and evidence into
              one navigable surface.
            </p>
          </div>
          <div className="min-h-64 bg-sidebar p-6">
            <div className="flex h-full min-h-52 items-center justify-center rounded-lg border border-sidebar-border bg-sidebar-accent/50">
              <div className="flex h-24 w-24 items-center justify-center rounded-full border border-primary bg-primary/85 font-serif text-3xl text-primary-foreground shadow-2xl">
                281
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}