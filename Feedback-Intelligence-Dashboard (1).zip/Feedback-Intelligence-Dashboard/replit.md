# Feedback Intelligence

An AI-ready feedback analysis workspace that turns pasted or uploaded comments into sentiment, theme, trend, and evidence insights.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm --filter @workspace/feedback-intelligence run dev` — run the dashboard
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/feedback-intelligence/src/App.tsx` — dashboard UI, sample workspace, CSV/text intake, filters, evidence view, and API mutation wiring
- `artifacts/feedback-intelligence/src/index.css` — workspace theme and responsive visual system
- `artifacts/api-server/src/routes/feedback.ts` — analysis endpoint implementation
- `lib/api-spec/openapi.yaml` — source of truth for `POST /api/feedback/analyze`

## Architecture decisions
- The dashboard ships with a sample analysis so judges can understand the product before uploading data.
- User-provided feedback goes through the generated `useAnalyzeFeedback` hook rather than a hand-written fetch call.
- The analysis response is domain-neutral: each entry can optionally include a category and date, so the same UI works for colleges, retail, hospitals, and support teams.

## Product
- Upload a CSV or paste one comment per line.
- See sentiment share, average signal, trend direction, recurring language, and analyst notes.
- Filter and search the evidence table by sentiment and theme.
- Copy a decision brief or export a snapshot for sharing with a team.

## User preferences

Keep the frontend easy to connect to a future AI analysis backend.

## Gotchas
- Run API codegen after editing `lib/api-spec/openapi.yaml`.
- The app uses the shared proxy path `/api`; do not hardcode localhost URLs in frontend code.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
